export default class Book{
    constructor(name, genre, price){
        this.name = name
        this.genre = genre
        this.price = price

    }

}
const BookOne1 = new Book("1984", "Sci-fi", 4)
const BookOne2 = new Book("1985", "Sci-fi", 5)
const BookOne3 = new Book("1986", "Sci-fi", 6)
const BookOne4 = new Book("1987", "Sci-fi", 7)
