import React from 'react';

const carting = () => {
  return (
    <div>

    </div>
  )
}

export default carting;
