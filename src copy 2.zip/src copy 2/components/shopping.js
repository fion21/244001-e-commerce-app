import React from 'react';

const shopping = () => {
  return (
    <div>

    </div>
  )
}

export default shopping;
